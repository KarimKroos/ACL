// External variables
const express = require("express");
const mongoose = require('mongoose');
const courseRoutes = require('./Routes/courses')
const MongoURI = "mongodb+srv://kady:AaBbCc112233@cluster0.ytbnyxa.mongodb.net/?retryWrites=true&w=majority";

//App variables
const app = express();
const port = process.env.PORT || "8000";
const course = require('./Models/courseModel');
const bodyParser = require('body-parser');

// #Importing the courseController
// configurations

/*
                Start of your code
*/

// #Routing to courseController here
app.use(bodyParser.json()); // for parsing application/json
app.use(bodyParser.urlencoded({ extended: true })); // for parsing application/x-www-form-urlencoded
app.use(express.json());
app.use("/api/courses",courseRoutes)

// Mongo DB
mongoose.connect(MongoURI)
.then(()=>{
  console.log("MongoDB is now connected!")
// Starting server
 app.listen(port, () => {
    console.log(`Listening to requests on http://localhost:${port}`);
  })
})
.catch(err => console.log(err));

/*
                                                    End of your code
*/